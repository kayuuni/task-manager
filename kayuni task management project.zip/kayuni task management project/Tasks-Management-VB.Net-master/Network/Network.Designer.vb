﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Network
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Network))
        Me.LstTaskBox = New System.Windows.Forms.ListBox()
        Me.FloLayTaskListContainer = New System.Windows.Forms.FlowLayoutPanel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.cmdNewTask = New System.Windows.Forms.Button()
        Me.cmdLaunchBoxNewTaskList = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BoxCreateNewTaskList = New System.Windows.Forms.GroupBox()
        Me.cmdCancelInCreateNewTasListBox = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmdCreateNewTaskList = New System.Windows.Forms.Button()
        Me.txtNewTaskListName = New System.Windows.Forms.TextBox()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindReplaceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckSpellingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ParagraphToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OnlineHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GettingSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckForUpdatesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReleaseNotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TechnicalSupportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SignInBox = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBoxYearOfBirth = New System.Windows.Forms.ComboBox()
        Me.lblUserID = New System.Windows.Forms.Label()
        Me.cmdRegsiter = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPasswordRegister = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtEmailAddressRegister = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.cmdLogIn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtEmailAddress = New System.Windows.Forms.TextBox()
        Me.lblInterfaceID = New System.Windows.Forms.Label()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskListToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OnlineHelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GettingStartedGuideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckForUpdatesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReleaseNotesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TechnicalHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindAndReplaceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckSpellingToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTaskListToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindAndReplaceToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckSpellingToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OnlineHelpToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GettingStartedGuideToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckForUpdatesToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReleaseNotesToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TechnicalSupportToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.BoxCreateNewTaskList.SuspendLayout()
        Me.SignInBox.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LstTaskBox
        '
        Me.LstTaskBox.FormattingEnabled = True
        Me.LstTaskBox.ItemHeight = 25
        Me.LstTaskBox.Location = New System.Drawing.Point(1462, 1056)
        Me.LstTaskBox.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.LstTaskBox.Name = "LstTaskBox"
        Me.LstTaskBox.Size = New System.Drawing.Size(236, 29)
        Me.LstTaskBox.TabIndex = 3
        Me.LstTaskBox.Visible = False
        '
        'FloLayTaskListContainer
        '
        Me.FloLayTaskListContainer.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FloLayTaskListContainer.AutoScroll = True
        Me.FloLayTaskListContainer.BackColor = System.Drawing.Color.Transparent
        Me.FloLayTaskListContainer.Location = New System.Drawing.Point(12, 260)
        Me.FloLayTaskListContainer.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.FloLayTaskListContainer.Name = "FloLayTaskListContainer"
        Me.FloLayTaskListContainer.Size = New System.Drawing.Size(1616, 496)
        Me.FloLayTaskListContainer.TabIndex = 90
        Me.FloLayTaskListContainer.WrapContents = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.FlowLayoutPanel2)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.FloLayTaskListContainer)
        Me.GroupBox1.Location = New System.Drawing.Point(74, 150)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(1642, 767)
        Me.GroupBox1.TabIndex = 800
        Me.GroupBox1.TabStop = False
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.FlowLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel2.Controls.Add(Me.cmdNewTask)
        Me.FlowLayoutPanel2.Controls.Add(Me.cmdLaunchBoxNewTaskList)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(12, 185)
        Me.FlowLayoutPanel2.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(1616, 69)
        Me.FlowLayoutPanel2.TabIndex = 90
        '
        'cmdNewTask
        '
        Me.cmdNewTask.Location = New System.Drawing.Point(6, 6)
        Me.cmdNewTask.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdNewTask.Name = "cmdNewTask"
        Me.cmdNewTask.Size = New System.Drawing.Size(232, 62)
        Me.cmdNewTask.TabIndex = 90
        Me.cmdNewTask.Text = "New Task"
        Me.cmdNewTask.UseVisualStyleBackColor = True
        '
        'cmdLaunchBoxNewTaskList
        '
        Me.cmdLaunchBoxNewTaskList.Location = New System.Drawing.Point(250, 6)
        Me.cmdLaunchBoxNewTaskList.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdLaunchBoxNewTaskList.Name = "cmdLaunchBoxNewTaskList"
        Me.cmdLaunchBoxNewTaskList.Size = New System.Drawing.Size(232, 62)
        Me.cmdLaunchBoxNewTaskList.TabIndex = 90
        Me.cmdLaunchBoxNewTaskList.Text = "New Tast list"
        Me.cmdLaunchBoxNewTaskList.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(510, 60)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox2.Size = New System.Drawing.Size(508, 98)
        Me.GroupBox2.TabIndex = 300
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Current Task"
        Me.GroupBox2.Visible = False
        '
        'BoxCreateNewTaskList
        '
        Me.BoxCreateNewTaskList.BackColor = System.Drawing.Color.Beige
        Me.BoxCreateNewTaskList.Controls.Add(Me.cmdCancelInCreateNewTasListBox)
        Me.BoxCreateNewTaskList.Controls.Add(Me.Label8)
        Me.BoxCreateNewTaskList.Controls.Add(Me.cmdCreateNewTaskList)
        Me.BoxCreateNewTaskList.Controls.Add(Me.txtNewTaskListName)
        Me.BoxCreateNewTaskList.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BoxCreateNewTaskList.Location = New System.Drawing.Point(396, 81)
        Me.BoxCreateNewTaskList.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.BoxCreateNewTaskList.Name = "BoxCreateNewTaskList"
        Me.BoxCreateNewTaskList.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.BoxCreateNewTaskList.Size = New System.Drawing.Size(564, 142)
        Me.BoxCreateNewTaskList.TabIndex = 6
        Me.BoxCreateNewTaskList.TabStop = False
        Me.BoxCreateNewTaskList.Text = "Create New Task List"
        Me.BoxCreateNewTaskList.Visible = False
        '
        'cmdCancelInCreateNewTasListBox
        '
        Me.cmdCancelInCreateNewTasListBox.Location = New System.Drawing.Point(394, 81)
        Me.cmdCancelInCreateNewTasListBox.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdCancelInCreateNewTasListBox.Name = "cmdCancelInCreateNewTasListBox"
        Me.cmdCancelInCreateNewTasListBox.Size = New System.Drawing.Size(150, 44)
        Me.cmdCancelInCreateNewTasListBox.TabIndex = 91
        Me.cmdCancelInCreateNewTasListBox.Text = "Cancel"
        Me.cmdCancelInCreateNewTasListBox.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 44)
        Me.Label8.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 25)
        Me.Label8.TabIndex = 80
        Me.Label8.Text = "Name:"
        '
        'cmdCreateNewTaskList
        '
        Me.cmdCreateNewTaskList.Location = New System.Drawing.Point(226, 81)
        Me.cmdCreateNewTaskList.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdCreateNewTaskList.Name = "cmdCreateNewTaskList"
        Me.cmdCreateNewTaskList.Size = New System.Drawing.Size(150, 44)
        Me.cmdCreateNewTaskList.TabIndex = 90
        Me.cmdCreateNewTaskList.Text = "Create"
        Me.cmdCreateNewTaskList.UseVisualStyleBackColor = True
        '
        'txtNewTaskListName
        '
        Me.txtNewTaskListName.Location = New System.Drawing.Point(14, 85)
        Me.txtNewTaskListName.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtNewTaskListName.Name = "txtNewTaskListName"
        Me.txtNewTaskListName.Size = New System.Drawing.Size(196, 31)
        Me.txtNewTaskListName.TabIndex = 70
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewTaskToolStripMenuItem, Me.NewTaskListToolStripMenuItem, Me.SignOutToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewTaskToolStripMenuItem
        '
        Me.NewTaskToolStripMenuItem.Name = "NewTaskToolStripMenuItem"
        Me.NewTaskToolStripMenuItem.Size = New System.Drawing.Size(253, 38)
        Me.NewTaskToolStripMenuItem.Text = "New Task"
        '
        'NewTaskListToolStripMenuItem
        '
        Me.NewTaskListToolStripMenuItem.Name = "NewTaskListToolStripMenuItem"
        Me.NewTaskListToolStripMenuItem.Size = New System.Drawing.Size(253, 38)
        Me.NewTaskListToolStripMenuItem.Text = "New Task list"
        '
        'SignOutToolStripMenuItem
        '
        Me.SignOutToolStripMenuItem.Name = "SignOutToolStripMenuItem"
        Me.SignOutToolStripMenuItem.Size = New System.Drawing.Size(253, 38)
        Me.SignOutToolStripMenuItem.Text = "Sign out"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(253, 38)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.DeleteToolStripMenuItem, Me.FindReplaceToolStripMenuItem, Me.CheckSpellingToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.UndoToolStripMenuItem.Text = "Undo"
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.RedoToolStripMenuItem.Text = "Redo"
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.CutToolStripMenuItem.Text = "Cut"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'FindReplaceToolStripMenuItem
        '
        Me.FindReplaceToolStripMenuItem.Name = "FindReplaceToolStripMenuItem"
        Me.FindReplaceToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.FindReplaceToolStripMenuItem.Text = "Find and Replace"
        '
        'CheckSpellingToolStripMenuItem
        '
        Me.CheckSpellingToolStripMenuItem.Name = "CheckSpellingToolStripMenuItem"
        Me.CheckSpellingToolStripMenuItem.Size = New System.Drawing.Size(297, 38)
        Me.CheckSpellingToolStripMenuItem.Text = "Check Spelling..."
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'TaskToolStripMenuItem
        '
        Me.TaskToolStripMenuItem.Name = "TaskToolStripMenuItem"
        Me.TaskToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.TaskToolStripMenuItem.Text = "Task"
        '
        'FormatToolStripMenuItem
        '
        Me.FormatToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FontToolStripMenuItem, Me.ParagraphToolStripMenuItem})
        Me.FormatToolStripMenuItem.Name = "FormatToolStripMenuItem"
        Me.FormatToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.FormatToolStripMenuItem.Text = "Format"
        '
        'FontToolStripMenuItem
        '
        Me.FontToolStripMenuItem.Name = "FontToolStripMenuItem"
        Me.FontToolStripMenuItem.Size = New System.Drawing.Size(221, 38)
        Me.FontToolStripMenuItem.Text = "Font"
        '
        'ParagraphToolStripMenuItem
        '
        Me.ParagraphToolStripMenuItem.Name = "ParagraphToolStripMenuItem"
        Me.ParagraphToolStripMenuItem.Size = New System.Drawing.Size(221, 38)
        Me.ParagraphToolStripMenuItem.Text = "Paragraph"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OnlineHelpToolStripMenuItem, Me.GettingSToolStripMenuItem, Me.CheckForUpdatesToolStripMenuItem, Me.ReleaseNotesToolStripMenuItem, Me.TechnicalSupportToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'OnlineHelpToolStripMenuItem
        '
        Me.OnlineHelpToolStripMenuItem.Name = "OnlineHelpToolStripMenuItem"
        Me.OnlineHelpToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.OnlineHelpToolStripMenuItem.Text = "Online Help"
        '
        'GettingSToolStripMenuItem
        '
        Me.GettingSToolStripMenuItem.Name = "GettingSToolStripMenuItem"
        Me.GettingSToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.GettingSToolStripMenuItem.Text = "Getting Started Guide"
        '
        'CheckForUpdatesToolStripMenuItem
        '
        Me.CheckForUpdatesToolStripMenuItem.Name = "CheckForUpdatesToolStripMenuItem"
        Me.CheckForUpdatesToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.CheckForUpdatesToolStripMenuItem.Text = "Check for updates"
        '
        'ReleaseNotesToolStripMenuItem
        '
        Me.ReleaseNotesToolStripMenuItem.Name = "ReleaseNotesToolStripMenuItem"
        Me.ReleaseNotesToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.ReleaseNotesToolStripMenuItem.Text = "Release notes"
        '
        'TechnicalSupportToolStripMenuItem
        '
        Me.TechnicalSupportToolStripMenuItem.Name = "TechnicalSupportToolStripMenuItem"
        Me.TechnicalSupportToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.TechnicalSupportToolStripMenuItem.Text = "Technical Support"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(346, 38)
        Me.AboutToolStripMenuItem.Text = "About..."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label9.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label9.Location = New System.Drawing.Point(66, 106)
        Me.Label9.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 36)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Label9"
        Me.Label9.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(788, 44)
        Me.Label10.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(103, 30)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Label10"
        Me.Label10.Visible = False
        '
        'SignInBox
        '
        Me.SignInBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SignInBox.Controls.Add(Me.GroupBox3)
        Me.SignInBox.Controls.Add(Me.cmdLogIn)
        Me.SignInBox.Controls.Add(Me.Label2)
        Me.SignInBox.Controls.Add(Me.Label1)
        Me.SignInBox.Controls.Add(Me.txtPassword)
        Me.SignInBox.Controls.Add(Me.txtEmailAddress)
        Me.SignInBox.Location = New System.Drawing.Point(72, 106)
        Me.SignInBox.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.SignInBox.Name = "SignInBox"
        Me.SignInBox.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.SignInBox.Size = New System.Drawing.Size(1642, 888)
        Me.SignInBox.TabIndex = 7
        Me.SignInBox.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.ComboBoxYearOfBirth)
        Me.GroupBox3.Controls.Add(Me.lblUserID)
        Me.GroupBox3.Controls.Add(Me.cmdRegsiter)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtPasswordRegister)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.txtEmailAddressRegister)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtLastName)
        Me.GroupBox3.Controls.Add(Me.txtFirstName)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(956, 273)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox3.Size = New System.Drawing.Size(674, 460)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Registration"
        '
        'ComboBoxYearOfBirth
        '
        Me.ComboBoxYearOfBirth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxYearOfBirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxYearOfBirth.FormattingEnabled = True
        Me.ComboBoxYearOfBirth.Location = New System.Drawing.Point(232, 179)
        Me.ComboBoxYearOfBirth.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.ComboBoxYearOfBirth.Name = "ComboBoxYearOfBirth"
        Me.ComboBoxYearOfBirth.Size = New System.Drawing.Size(416, 52)
        Me.ComboBoxYearOfBirth.TabIndex = 6
        '
        'lblUserID
        '
        Me.lblUserID.AutoSize = True
        Me.lblUserID.Location = New System.Drawing.Point(40, 402)
        Me.lblUserID.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Size = New System.Drawing.Size(176, 44)
        Me.lblUserID.TabIndex = 14
        Me.lblUserID.Text = "lblUserID"
        Me.lblUserID.Visible = False
        '
        'cmdRegsiter
        '
        Me.cmdRegsiter.Location = New System.Drawing.Point(466, 377)
        Me.cmdRegsiter.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdRegsiter.Name = "cmdRegsiter"
        Me.cmdRegsiter.Size = New System.Drawing.Size(190, 71)
        Me.cmdRegsiter.TabIndex = 9
        Me.cmdRegsiter.Text = "Register"
        Me.cmdRegsiter.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(12, 323)
        Me.Label7.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(155, 36)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Password:"
        '
        'txtPasswordRegister
        '
        Me.txtPasswordRegister.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPasswordRegister.Location = New System.Drawing.Point(232, 310)
        Me.txtPasswordRegister.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtPasswordRegister.MaxLength = 100
        Me.txtPasswordRegister.Name = "txtPasswordRegister"
        Me.txtPasswordRegister.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPasswordRegister.Size = New System.Drawing.Size(420, 51)
        Me.txtPasswordRegister.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 258)
        Me.Label5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(215, 36)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Email Address:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(12, 192)
        Me.Label6.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(188, 36)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Year of Birth:"
        '
        'txtEmailAddressRegister
        '
        Me.txtEmailAddressRegister.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailAddressRegister.Location = New System.Drawing.Point(232, 244)
        Me.txtEmailAddressRegister.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtEmailAddressRegister.MaxLength = 100
        Me.txtEmailAddressRegister.Name = "txtEmailAddressRegister"
        Me.txtEmailAddressRegister.Size = New System.Drawing.Size(420, 51)
        Me.txtEmailAddressRegister.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 129)
        Me.Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(164, 36)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Last Name:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 63)
        Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(166, 36)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "First Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(232, 115)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtLastName.MaxLength = 100
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(420, 51)
        Me.txtLastName.TabIndex = 5
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(232, 50)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtFirstName.MaxLength = 100
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(420, 51)
        Me.txtFirstName.TabIndex = 4
        '
        'cmdLogIn
        '
        Me.cmdLogIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLogIn.Location = New System.Drawing.Point(1418, 190)
        Me.cmdLogIn.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.cmdLogIn.Name = "cmdLogIn"
        Me.cmdLogIn.Size = New System.Drawing.Size(190, 71)
        Me.cmdLogIn.TabIndex = 2
        Me.cmdLogIn.Text = "Sign-in"
        Me.cmdLogIn.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(964, 125)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(155, 36)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(964, 60)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(215, 36)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Email Address:"
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(1188, 112)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtPassword.MaxLength = 100
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(420, 51)
        Me.txtPassword.TabIndex = 1
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailAddress.Location = New System.Drawing.Point(1188, 44)
        Me.txtEmailAddress.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtEmailAddress.MaxLength = 100
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.txtEmailAddress.Size = New System.Drawing.Size(420, 51)
        Me.txtEmailAddress.TabIndex = 0
        '
        'lblInterfaceID
        '
        Me.lblInterfaceID.AutoSize = True
        Me.lblInterfaceID.Location = New System.Drawing.Point(886, 1062)
        Me.lblInterfaceID.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblInterfaceID.Name = "lblInterfaceID"
        Me.lblInterfaceID.Size = New System.Drawing.Size(170, 25)
        Me.lblInterfaceID.TabIndex = 10
        Me.lblInterfaceID.Text = "RefreshInterface"
        Me.lblInterfaceID.Visible = False
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'NewTaskToolStripMenuItem1
        '
        Me.NewTaskToolStripMenuItem1.Name = "NewTaskToolStripMenuItem1"
        Me.NewTaskToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewTaskToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.NewTaskToolStripMenuItem1.Text = "New Task"
        '
        'NewTaskListToolStripMenuItem1
        '
        Me.NewTaskListToolStripMenuItem1.Name = "NewTaskListToolStripMenuItem1"
        Me.NewTaskListToolStripMenuItem1.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewTaskListToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.NewTaskListToolStripMenuItem1.Text = "New Task list"
        '
        'SignOutToolStripMenuItem1
        '
        Me.SignOutToolStripMenuItem1.Name = "SignOutToolStripMenuItem1"
        Me.SignOutToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.SignOutToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.SignOutToolStripMenuItem1.Text = "Sign Out"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'EditToolStripMenuItem1
        '
        Me.EditToolStripMenuItem1.Name = "EditToolStripMenuItem1"
        Me.EditToolStripMenuItem1.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem1.Text = "Edit"
        '
        'ViewToolStripMenuItem1
        '
        Me.ViewToolStripMenuItem1.Name = "ViewToolStripMenuItem1"
        Me.ViewToolStripMenuItem1.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem1.Text = "View"
        '
        'TaskToolStripMenuItem1
        '
        Me.TaskToolStripMenuItem1.Name = "TaskToolStripMenuItem1"
        Me.TaskToolStripMenuItem1.Size = New System.Drawing.Size(43, 20)
        Me.TaskToolStripMenuItem1.Text = "Task"
        '
        'FormatToolStripMenuItem1
        '
        Me.FormatToolStripMenuItem1.Name = "FormatToolStripMenuItem1"
        Me.FormatToolStripMenuItem1.Size = New System.Drawing.Size(57, 20)
        Me.FormatToolStripMenuItem1.Text = "Format"
        '
        'ToolsToolStripMenuItem1
        '
        Me.ToolsToolStripMenuItem1.Name = "ToolsToolStripMenuItem1"
        Me.ToolsToolStripMenuItem1.Size = New System.Drawing.Size(48, 20)
        Me.ToolsToolStripMenuItem1.Text = "Tools"
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem1.Text = "Help"
        '
        'OnlineHelpToolStripMenuItem1
        '
        Me.OnlineHelpToolStripMenuItem1.Name = "OnlineHelpToolStripMenuItem1"
        Me.OnlineHelpToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.OnlineHelpToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.OnlineHelpToolStripMenuItem1.Text = "Online Help"
        '
        'GettingStartedGuideToolStripMenuItem
        '
        Me.GettingStartedGuideToolStripMenuItem.Name = "GettingStartedGuideToolStripMenuItem"
        Me.GettingStartedGuideToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.GettingStartedGuideToolStripMenuItem.Text = "Getting Started Guide"
        '
        'CheckForUpdatesToolStripMenuItem1
        '
        Me.CheckForUpdatesToolStripMenuItem1.Name = "CheckForUpdatesToolStripMenuItem1"
        Me.CheckForUpdatesToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.CheckForUpdatesToolStripMenuItem1.Text = "Check for updates"
        '
        'ReleaseNotesToolStripMenuItem1
        '
        Me.ReleaseNotesToolStripMenuItem1.Name = "ReleaseNotesToolStripMenuItem1"
        Me.ReleaseNotesToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.ReleaseNotesToolStripMenuItem1.Text = "Release notes"
        '
        'TechnicalHelpToolStripMenuItem
        '
        Me.TechnicalHelpToolStripMenuItem.Name = "TechnicalHelpToolStripMenuItem"
        Me.TechnicalHelpToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.TechnicalHelpToolStripMenuItem.Text = "Technical Help"
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.AboutToolStripMenuItem1.Text = "About..."
        '
        'UndoToolStripMenuItem1
        '
        Me.UndoToolStripMenuItem1.Name = "UndoToolStripMenuItem1"
        Me.UndoToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.UndoToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.UndoToolStripMenuItem1.Text = "Undo"
        '
        'RedoToolStripMenuItem1
        '
        Me.RedoToolStripMenuItem1.Name = "RedoToolStripMenuItem1"
        Me.RedoToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RedoToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.RedoToolStripMenuItem1.Text = "Redo"
        '
        'CutToolStripMenuItem1
        '
        Me.CutToolStripMenuItem1.Name = "CutToolStripMenuItem1"
        Me.CutToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.CutToolStripMenuItem1.Text = "Cut"
        '
        'CopyToolStripMenuItem1
        '
        Me.CopyToolStripMenuItem1.Name = "CopyToolStripMenuItem1"
        Me.CopyToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.CopyToolStripMenuItem1.Text = "Copy"
        '
        'PasteToolStripMenuItem1
        '
        Me.PasteToolStripMenuItem1.Name = "PasteToolStripMenuItem1"
        Me.PasteToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.PasteToolStripMenuItem1.Text = "Paste"
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.ShortcutKeyDisplayString = "Delete"
        Me.DeleteToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.DeleteToolStripMenuItem1.Text = "Delete"
        '
        'FindAndReplaceToolStripMenuItem
        '
        Me.FindAndReplaceToolStripMenuItem.Name = "FindAndReplaceToolStripMenuItem"
        Me.FindAndReplaceToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.FindAndReplaceToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.FindAndReplaceToolStripMenuItem.Text = "Find and Replace"
        '
        'CheckSpellingToolStripMenuItem1
        '
        Me.CheckSpellingToolStripMenuItem1.Name = "CheckSpellingToolStripMenuItem1"
        Me.CheckSpellingToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F7
        Me.CheckSpellingToolStripMenuItem1.Size = New System.Drawing.Size(204, 22)
        Me.CheckSpellingToolStripMenuItem1.Text = "Check Spelling"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem2, Me.EditToolStripMenuItem2, Me.ViewToolStripMenuItem2, Me.TaskToolStripMenuItem2, Me.FormatToolStripMenuItem2, Me.ToolsToolStripMenuItem2, Me.HelpToolStripMenuItem2})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(12, 4, 0, 4)
        Me.MenuStrip1.Size = New System.Drawing.Size(1782, 44)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem2
        '
        Me.FileToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewTaskToolStripMenuItem2, Me.NewTaskListToolStripMenuItem2, Me.SignOutToolStripMenuItem2, Me.ExitToolStripMenuItem2})
        Me.FileToolStripMenuItem2.Name = "FileToolStripMenuItem2"
        Me.FileToolStripMenuItem2.Size = New System.Drawing.Size(64, 36)
        Me.FileToolStripMenuItem2.Text = "File"
        '
        'NewTaskToolStripMenuItem2
        '
        Me.NewTaskToolStripMenuItem2.Name = "NewTaskToolStripMenuItem2"
        Me.NewTaskToolStripMenuItem2.Size = New System.Drawing.Size(258, 38)
        Me.NewTaskToolStripMenuItem2.Text = "New Task"
        '
        'NewTaskListToolStripMenuItem2
        '
        Me.NewTaskListToolStripMenuItem2.Name = "NewTaskListToolStripMenuItem2"
        Me.NewTaskListToolStripMenuItem2.Size = New System.Drawing.Size(258, 38)
        Me.NewTaskListToolStripMenuItem2.Text = "New Task List"
        '
        'SignOutToolStripMenuItem2
        '
        Me.SignOutToolStripMenuItem2.Name = "SignOutToolStripMenuItem2"
        Me.SignOutToolStripMenuItem2.Size = New System.Drawing.Size(258, 38)
        Me.SignOutToolStripMenuItem2.Text = "Sign out"
        '
        'ExitToolStripMenuItem2
        '
        Me.ExitToolStripMenuItem2.Name = "ExitToolStripMenuItem2"
        Me.ExitToolStripMenuItem2.Size = New System.Drawing.Size(258, 38)
        Me.ExitToolStripMenuItem2.Text = "Exit"
        '
        'EditToolStripMenuItem2
        '
        Me.EditToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem2, Me.RedoToolStripMenuItem2, Me.CutToolStripMenuItem2, Me.CopyToolStripMenuItem2, Me.PasteToolStripMenuItem2, Me.DeleteToolStripMenuItem2, Me.FindAndReplaceToolStripMenuItem1, Me.CheckSpellingToolStripMenuItem2})
        Me.EditToolStripMenuItem2.Name = "EditToolStripMenuItem2"
        Me.EditToolStripMenuItem2.Size = New System.Drawing.Size(67, 36)
        Me.EditToolStripMenuItem2.Text = "Edit"
        '
        'UndoToolStripMenuItem2
        '
        Me.UndoToolStripMenuItem2.Name = "UndoToolStripMenuItem2"
        Me.UndoToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.UndoToolStripMenuItem2.Text = "Undo"
        '
        'RedoToolStripMenuItem2
        '
        Me.RedoToolStripMenuItem2.Name = "RedoToolStripMenuItem2"
        Me.RedoToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.RedoToolStripMenuItem2.Text = "Redo"
        '
        'CutToolStripMenuItem2
        '
        Me.CutToolStripMenuItem2.Name = "CutToolStripMenuItem2"
        Me.CutToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.CutToolStripMenuItem2.Text = "Cut"
        '
        'CopyToolStripMenuItem2
        '
        Me.CopyToolStripMenuItem2.Name = "CopyToolStripMenuItem2"
        Me.CopyToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.CopyToolStripMenuItem2.Text = "Copy"
        '
        'PasteToolStripMenuItem2
        '
        Me.PasteToolStripMenuItem2.Name = "PasteToolStripMenuItem2"
        Me.PasteToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.PasteToolStripMenuItem2.Text = "Paste"
        '
        'DeleteToolStripMenuItem2
        '
        Me.DeleteToolStripMenuItem2.Name = "DeleteToolStripMenuItem2"
        Me.DeleteToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.DeleteToolStripMenuItem2.Text = "Delete"
        '
        'FindAndReplaceToolStripMenuItem1
        '
        Me.FindAndReplaceToolStripMenuItem1.Name = "FindAndReplaceToolStripMenuItem1"
        Me.FindAndReplaceToolStripMenuItem1.Size = New System.Drawing.Size(297, 38)
        Me.FindAndReplaceToolStripMenuItem1.Text = "Find and Replace"
        '
        'CheckSpellingToolStripMenuItem2
        '
        Me.CheckSpellingToolStripMenuItem2.Name = "CheckSpellingToolStripMenuItem2"
        Me.CheckSpellingToolStripMenuItem2.Size = New System.Drawing.Size(297, 38)
        Me.CheckSpellingToolStripMenuItem2.Text = "Check Spelling"
        '
        'ViewToolStripMenuItem2
        '
        Me.ViewToolStripMenuItem2.Name = "ViewToolStripMenuItem2"
        Me.ViewToolStripMenuItem2.Size = New System.Drawing.Size(78, 36)
        Me.ViewToolStripMenuItem2.Text = "View"
        '
        'TaskToolStripMenuItem2
        '
        Me.TaskToolStripMenuItem2.Name = "TaskToolStripMenuItem2"
        Me.TaskToolStripMenuItem2.Size = New System.Drawing.Size(74, 36)
        Me.TaskToolStripMenuItem2.Text = "Task"
        '
        'FormatToolStripMenuItem2
        '
        Me.FormatToolStripMenuItem2.Name = "FormatToolStripMenuItem2"
        Me.FormatToolStripMenuItem2.Size = New System.Drawing.Size(102, 36)
        Me.FormatToolStripMenuItem2.Text = "Format"
        '
        'ToolsToolStripMenuItem2
        '
        Me.ToolsToolStripMenuItem2.Name = "ToolsToolStripMenuItem2"
        Me.ToolsToolStripMenuItem2.Size = New System.Drawing.Size(84, 36)
        Me.ToolsToolStripMenuItem2.Text = "Tools"
        '
        'HelpToolStripMenuItem2
        '
        Me.HelpToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OnlineHelpToolStripMenuItem2, Me.GettingStartedGuideToolStripMenuItem1, Me.CheckForUpdatesToolStripMenuItem2, Me.ReleaseNotesToolStripMenuItem2, Me.TechnicalSupportToolStripMenuItem1, Me.AboutToolStripMenuItem2})
        Me.HelpToolStripMenuItem2.Name = "HelpToolStripMenuItem2"
        Me.HelpToolStripMenuItem2.Size = New System.Drawing.Size(77, 36)
        Me.HelpToolStripMenuItem2.Text = "Help"
        '
        'OnlineHelpToolStripMenuItem2
        '
        Me.OnlineHelpToolStripMenuItem2.Name = "OnlineHelpToolStripMenuItem2"
        Me.OnlineHelpToolStripMenuItem2.Size = New System.Drawing.Size(344, 38)
        Me.OnlineHelpToolStripMenuItem2.Text = "Online Help"
        '
        'GettingStartedGuideToolStripMenuItem1
        '
        Me.GettingStartedGuideToolStripMenuItem1.Name = "GettingStartedGuideToolStripMenuItem1"
        Me.GettingStartedGuideToolStripMenuItem1.Size = New System.Drawing.Size(344, 38)
        Me.GettingStartedGuideToolStripMenuItem1.Text = "Getting Started guide"
        '
        'CheckForUpdatesToolStripMenuItem2
        '
        Me.CheckForUpdatesToolStripMenuItem2.Name = "CheckForUpdatesToolStripMenuItem2"
        Me.CheckForUpdatesToolStripMenuItem2.Size = New System.Drawing.Size(344, 38)
        Me.CheckForUpdatesToolStripMenuItem2.Text = "Check for updates"
        '
        'ReleaseNotesToolStripMenuItem2
        '
        Me.ReleaseNotesToolStripMenuItem2.Name = "ReleaseNotesToolStripMenuItem2"
        Me.ReleaseNotesToolStripMenuItem2.Size = New System.Drawing.Size(344, 38)
        Me.ReleaseNotesToolStripMenuItem2.Text = "Release notes"
        '
        'TechnicalSupportToolStripMenuItem1
        '
        Me.TechnicalSupportToolStripMenuItem1.Name = "TechnicalSupportToolStripMenuItem1"
        Me.TechnicalSupportToolStripMenuItem1.Size = New System.Drawing.Size(344, 38)
        Me.TechnicalSupportToolStripMenuItem1.Text = "Technical Support"
        '
        'AboutToolStripMenuItem2
        '
        Me.AboutToolStripMenuItem2.Name = "AboutToolStripMenuItem2"
        Me.AboutToolStripMenuItem2.Size = New System.Drawing.Size(344, 38)
        Me.AboutToolStripMenuItem2.Text = "About..."
        '
        'Network
        '
        Me.AcceptButton = Me.cmdLogIn
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1782, 1110)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lblInterfaceID)
        Me.Controls.Add(Me.SignInBox)
        Me.Controls.Add(Me.BoxCreateNewTaskList)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.LstTaskBox)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.Name = "Network"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Tag = "80"
        Me.Text = "Tasks Manager"
        Me.GroupBox1.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.BoxCreateNewTaskList.ResumeLayout(False)
        Me.BoxCreateNewTaskList.PerformLayout()
        Me.SignInBox.ResumeLayout(False)
        Me.SignInBox.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LstTaskBox As System.Windows.Forms.ListBox
    Friend WithEvents FloLayTaskListContainer As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdLaunchBoxNewTaskList As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents cmdNewTask As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BoxCreateNewTaskList As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmdCreateNewTaskList As System.Windows.Forms.Button
    Friend WithEvents txtNewTaskListName As System.Windows.Forms.TextBox
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindReplaceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckSpellingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FontToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ParagraphToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OnlineHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GettingSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckForUpdatesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReleaseNotesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TechnicalSupportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SignInBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtEmailAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents cmdLogIn As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdRegsiter As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPasswordRegister As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtEmailAddressRegister As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblInterfaceID As System.Windows.Forms.Label
    Friend WithEvents FileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskListToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindAndReplaceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckSpellingToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OnlineHelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GettingStartedGuideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckForUpdatesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReleaseNotesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TechnicalHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblUserID As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTaskListToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindAndReplaceToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckSpellingToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OnlineHelpToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GettingStartedGuideToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckForUpdatesToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReleaseNotesToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TechnicalSupportToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmdCancelInCreateNewTasListBox As System.Windows.Forms.Button
    Friend WithEvents ComboBoxYearOfBirth As System.Windows.Forms.ComboBox

End Class
