﻿Public NotInheritable Class SplashScreen1

   
End Class
